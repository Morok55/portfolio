import React, { useEffect } from 'react'

const AllTechsPage = () => {


    useEffect(() => {
        window.scrollTo(0, 0);
    }, [])

    return (
        <>
        
        </>
    )
}

export default AllTechsPage
